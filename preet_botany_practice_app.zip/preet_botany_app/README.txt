ABHAY (PREET) BOTANY PRACTICE APP — STARTER VERSION

Files:
- index.html: mobile-friendly practice dashboard and answer tracker
- botany.pdf: original 149-page PDF supplied in chat

To use:
1. Keep index.html and botany.pdf in the same folder.
2. Open index.html in a browser, or upload the whole folder to a static hosting service.
3. For Android, the hosted website can be added to the home screen from Chrome (menu > Add to Home screen / Install app, where available).

Important limitation:
This starter app embeds the source PDF and saves selected answers, correct/wrong self-marking, notes, and progress locally. It does not yet automatically grade against the PDF's answer keys or extract every MCQ into individual cards. The PDF has complex multi-column pages and several exercise answer-key sections, so automated extraction needs validation to avoid silently changing questions or answers.
